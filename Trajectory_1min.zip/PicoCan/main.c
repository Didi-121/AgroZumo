/*
 * PicoCan - Seguidor de trayectoria para el Zumo 2040
 * TE2004B Advanced Embedded Systems - Second Delivery Challenge
 *
 * ---------------------------------------------------------------------------
 * QUE HACE
 * ---------------------------------------------------------------------------
 * El Zumo recorre la pista siguiendo la lista de waypoints (puntos[]) usando
 * la posicion que le da la camara del techo. La Pico 2 W (proyecto Pico2wCAN)
 * recibe la posicion por Wi-Fi y nos la manda por CAN:
 *
 *     ID 0x200 -> X y Y del robot (dos float, en metros)
 *     ID 0x201 -> angulo del robot (int32, en grados)
 *
 * Con cada posicion nueva el robot:
 *     1. Ve en que tramo de la pista esta (de un waypoint al siguiente).
 *     2. Busca un punto sobre la linea del tramo un poco mas adelante y
 *        calcula el angulo para llegar a el.
 *     3. Si el error de angulo es muy grande, gira en su lugar. Si no, avanza
 *        girando: una oruga va mas rapido que la otra y asi hace la curva.
 *     4. Cuando ya esta cerca del waypoint, cambia al siguiente sin detenerse.
 *     5. Al completar una vuelta regresa al punto donde arranco y se detiene.
 *
 * Arranca en el waypoint mas cercano a donde lo pongas, no hace falta
 * colocarlo exacto. Para dar otra vuelta hay que reiniciar la Pico.
 *
 * ---------------------------------------------------------------------------
 * VARIABLES QUE PUEDEN MOVER
 * ---------------------------------------------------------------------------
 * Velocidad (los motores van de -6000 a 6000, no son m/s):
 *
 *   VEL_RECTA       Que tan rapido va en las rectas largas. Si la suben, la
 *                   vuelta tarda menos, pero se puede salir de la pista al
 *                   entrar a las curvas.
 *   VEL_CURVA       Velocidad en las curvas y al llegar a ellas. Abajo de
 *                   ~1000 las orugas se atoran. Si la suben, las curvas
 *                   salen mas abiertas.
 *   TRAMO_LARGO     Un tramo mas largo que esto (en metros) se toma como
 *                   recta y usa VEL_RECTA.
 *   FRENAR_ANTES    Cuantos metros antes del final de una recta baja a
 *                   VEL_CURVA para entrar bien a la curva.
 *   VEL_GIRO_MIN    Fuerza minima para girar en su lugar. Con orugas se
 *   VEL_GIRO_MAX    necesita mucha; con 1200 casi no giraba.
 *
 * Correccion de angulo (control PD):
 *
 *   KP_ANGULO       Que tan fuerte corrige por cada grado de error. Si lo
 *                   suben, corrige mas rapido pero puede zigzaguear.
 *   KD_ANGULO       Frena la correccion cuando ya va llegando al angulo,
 *                   para que no se pase. Si zigzaguea, subanlo un poco.
 *   FILTRO_D_SEG    Suaviza el ruido de la camara en la parte D. Normalmente
 *                   no se toca.
 *   CORRECCION_MAX  Diferencia maxima entre las dos orugas al avanzar. Mas
 *                   grande = curvas mas cerradas.
 *   SENTIDO_ANGULO  1 o -1. Si el robot gira para el lado contrario al que
 *                   deberia, cambien el signo. Con nuestro robot es 1.
 *
 * Trayectoria:
 *
 *   RADIO_CAMBIO    A cuantos metros del waypoint ya se va al siguiente. Mas
 *                   grande = empieza a girar antes y corta mas la curva.
 *   RADIO_FINAL     Que tan cerca tiene que quedar del punto final para
 *                   detenerse.
 *   ADELANTE        Que tan adelante sobre la linea apunta el robot. Mas
 *                   chico = regresa mas rapido a la linea pero zigzaguea;
 *                   mas grande = va mas suave pero tarda en corregir.
 *   GIRO_EN_SITIO   Si el error de angulo es mayor a esto (grados), gira en
 *                   su lugar en vez de avanzar girando.
 *   MARGEN_MAPA     Las lecturas de la camara que caen fuera del mapa (mas
 *                   este margen) se ignoran.
 *
 * Tiempos (milisegundos):
 *
 *   VENTANA_DATO_MS   Cuanto tiempo sigue moviendose sin recibir otra
 *                     posicion. Si se pasa, se detiene y espera. La camara
 *                     a veces tarda 400-550 ms, por eso esta en 600.
 *   GIRO_TIMEOUT_MS   Si lleva este tiempo girando y no se alinea, se
 *                     detiene con FALLO (motores o SENTIDO_ANGULO mal).
 *   SIN_PROGRESO_MS   Si en este tiempo no se acerca al waypoint, FALLO.
 *   TRAMO_TIMEOUT_MS  Tiempo maximo para un tramo.
 *   CONTROL_MS        Cada cuanto se recalculan los motores aunque no llegue
 *                     posicion nueva.
 *   REPORTE_MS        Cada cuanto imprime una linea en el monitor serial.
 *
 * Mapa:
 *
 *   puntos[]        Los waypoints en el orden de la pista (X, Y en metros y
 *                   angulo en grados). Los W son la posicion en la lista y
 *                   los P son los puntos del PDF. En cada vuelta en U hay un
 *                   punto intermedio para que el robot haga la curva. El
 *                   angulo es solo de referencia, el robot no lo usa.
 *
 * ---------------------------------------------------------------------------
 * FUNCIONES
 * ---------------------------------------------------------------------------
 * Modulo CAN (MCP2515 por SPI0: MISO=GP0, CS=GP1, SCK=GP2, MOSI=GP3)
 *   mcp_leer / mcp_escribir / mcp_modificar   Leen y escriben registros.
 *   mcp_modo        Cambia el modo del MCP2515 (configuracion o normal).
 *   mcp_iniciar     Configura el SPI y el CAN a 500 kbps (cristal de 8 MHz),
 *                   igual que Pico2wCAN. Tambien pone GP6 en bajo porque GP3
 *                   llega a los LEDs RGB del Zumo.
 *   mcp_recibir     Lee un mensaje CAN si hay uno.
 *
 * Recepcion
 *   procesar_can    Junta X,Y (0x200) con el angulo (0x201) para armar una
 *                   posicion completa. Ignora datos raros o fuera del mapa.
 *   dentro_del_mapa Revisa que la posicion caiga dentro del mapa.
 *   normalizar      Deja cualquier angulo entre -180 y 180.
 *
 * Control
 *   controlar       La funcion principal: decide que hacer con los motores
 *                   en cada ciclo (esperar, girar en su lugar o avanzar).
 *   rumbo_en_tramo  Calcula el angulo hacia el punto de adelante sobre la
 *                   linea del tramo actual.
 *   rumbo_a         Angulo desde el robot hacia un punto.
 *   llego           Dice si ya toca cambiar al siguiente waypoint.
 *   es_el_final     Dice si el waypoint que sigue es el que cierra la vuelta.
 *   velocidad_base  Elige VEL_RECTA o VEL_CURVA segun el tramo.
 *   calcular_pd     Control PD: cuanto corregir segun el error de angulo.
 *   punto_mas_cercano  Waypoint mas cercano al robot (para arrancar).
 *   motores         Manda la velocidad a cada oruga y guarda el motivo.
 *   fallo           Detiene el robot por un error.
 *
 * Monitor
 *   reportar        Imprime una linea con lo que esta haciendo el robot.
 *
 * ---------------------------------------------------------------------------
 * COMO LEER EL MONITOR SERIAL
 * ---------------------------------------------------------------------------
 *   AVANZANDO W3->W4 Avanzar recto|xy=-0.20,0.80 a=-88 o=-90 e=-2 d=0.38 ...
 *
 *   estado   ESPERANDO, ALINEANDO (girando en su lugar), AVANZANDO,
 *            FALLO o TERMINADO
 *   W3->W4   va del waypoint 3 al 4
 *   xy, a    posicion y angulo que manda la camara
 *   o, e     angulo al que quiere apuntar y el error
 *   d        metros que le faltan para el waypoint
 *   m        velocidad que se mando a la oruga izquierda/derecha
 *   edad     ms desde la ultima posicion; per = cada cuanto llegan
 */

#include <math.h>
#include <stdio.h>
#include <string.h>
#include <pololu_zumo_2040_robot.h>
#include "pico/stdlib.h"
#include "hardware/spi.h"
#include "hardware/gpio.h"

/* ---------------- Ajustes ---------------- */

#define CAN_POS_ID          0x200
#define CAN_ANGLE_ID        0x201

#define VEL_RECTA           2000
#define VEL_CURVA           1200
#define TRAMO_LARGO         0.30f
#define FRENAR_ANTES        0.15f
#define VEL_GIRO_MIN        1500
#define VEL_GIRO_MAX        3000

#define KP_ANGULO           60.0f
#define KD_ANGULO           1.0f
#define FILTRO_D_SEG        0.08f
#define CORRECCION_MAX      1100.0f
#define SENTIDO_ANGULO      1

#define RADIO_CAMBIO        0.08f
#define RADIO_FINAL         0.03f
#define ADELANTE            0.15f
#define GIRO_EN_SITIO       60.0f
#define MARGEN_MAPA         0.30f

#define VENTANA_DATO_MS     600
#define GIRO_TIMEOUT_MS     8000
#define SIN_PROGRESO_MS     4000
#define TRAMO_TIMEOUT_MS    30000
#define CONTROL_MS          10
#define REPORTE_MS          100

/* ---------------- Mapa de la pista ---------------- */

typedef struct {
    float x, y;
    int32_t angle;
} Punto;

static const Punto puntos[] = {
    //   X       Y     Angulo
    { -0.37f,  1.1f,    90 },  // W1  P1
    //{ -0.35f,  1.14f,     0 },  // W2  curva P1-P2
    { -0.22f,  1.1f,   -90 },  // W3  P2
    { -0.22f,  0.30f,   -90 },  // W4  P3
    //{ -0.19f,  0.25f,     0 },  // W5  curva P3-P4
    { -0.08f,  0.30f,    90 },  // W6  P4
    { -0.08f,  1.1f,    90 },  // W7  P5
    //{ -0.06f,  1.14f,     3 },  // W8  curva P5-P6
    {  0.07f,  1.1f,   -90 },  // W9  P6
    {  0.07f,  0.30f,   -90 },  // W10 P7
    //{  0.10f,  0.27f,    -2 },  // W11 curva P7-P8
    {  0.22f,  0.30f,    90 },  // W12 P8
    {  0.22f,  1.1f,    90 },  // W13 P9
    //{  0.24f,  1.13f,    -2 },  // W14 curva P9-P10
    {  0.37f,  1.1f,   -90 },  // W15 P10
    {  0.37f,  0.1f,   -90 },  // W16 P11
    //{  0.37f,  0.1f,  -180 },  // W17 curva P11-P12
    {  0.37f,  0.1f,  -180 },  // W18 P12
    { -0.37f,  0.1f,  -180 },  // W19 P13
    //{ -0.37f,  0.07f,   180 },  // W20 curva P13-P14
    { -0.37f,  0.1f,    90 },  // W21 P14
};
#define NUM_PUNTOS ((int)(sizeof(puntos) / sizeof(puntos[0])))

/* ---------------- Modulo CAN MCP2515 ---------------- */

#define MCP_SPI          spi0
#define MCP_PIN_MISO     0
#define MCP_PIN_CS       1
#define MCP_PIN_SCK      2
#define MCP_PIN_MOSI     3
#define MCP_SPI_BAUD     1000000u

#define MCP_RESET        0xC0
#define MCP_READ         0x03
#define MCP_WRITE        0x02
#define MCP_BIT_MODIFY   0x05
#define MCP_CANSTAT      0x0E
#define MCP_CANCTRL      0x0F
#define MCP_CNF3         0x28
#define MCP_CNF2         0x29
#define MCP_CNF1         0x2A
#define MCP_CANINTF      0x2C
#define MCP_RXB0CTRL     0x60
#define MCP_RXB1CTRL     0x70
#define MCP_RX0IF        0x01
#define MCP_RX1IF        0x02
#define MCP_MODO_NORMAL  0x00
#define MCP_MODO_CONFIG  0x80
#define MCP_MODO_MASK    0xE0

typedef struct {
    uint32_t id;
    uint8_t dlc;
    uint8_t data[8];
} can_frame_t;

static void cs(bool activo) { gpio_put(MCP_PIN_CS, !activo); }

static uint8_t mcp_leer(uint8_t reg) {
    uint8_t tx[3] = { MCP_READ, reg, 0 }, rx[3];
    cs(true); spi_write_read_blocking(MCP_SPI, tx, rx, 3); cs(false);
    return rx[2];
}

static void mcp_escribir(uint8_t reg, uint8_t valor) {
    uint8_t tx[3] = { MCP_WRITE, reg, valor };
    cs(true); spi_write_blocking(MCP_SPI, tx, 3); cs(false);
}

static void mcp_modificar(uint8_t reg, uint8_t mascara, uint8_t valor) {
    uint8_t tx[4] = { MCP_BIT_MODIFY, reg, mascara, valor };
    cs(true); spi_write_blocking(MCP_SPI, tx, 4); cs(false);
}

static bool mcp_modo(uint8_t modo) {
    mcp_modificar(MCP_CANCTRL, MCP_MODO_MASK, modo);
    for (int i = 0; i < 100; i++) {
        if ((mcp_leer(MCP_CANSTAT) & MCP_MODO_MASK) == modo) return true;
        sleep_ms(1);
    }
    return false;
}

static bool mcp_iniciar(void) {
    gpio_init(6); gpio_put(6, 0); gpio_set_dir(6, GPIO_OUT);

    gpio_init(MCP_PIN_CS); gpio_put(MCP_PIN_CS, 1); gpio_set_dir(MCP_PIN_CS, GPIO_OUT);
    spi_init(MCP_SPI, MCP_SPI_BAUD);
    gpio_set_function(MCP_PIN_MISO, GPIO_FUNC_SPI);
    gpio_set_function(MCP_PIN_SCK,  GPIO_FUNC_SPI);
    gpio_set_function(MCP_PIN_MOSI, GPIO_FUNC_SPI);

    uint8_t reset = MCP_RESET;
    cs(true); spi_write_blocking(MCP_SPI, &reset, 1); cs(false);
    sleep_ms(10);

    if (!mcp_modo(MCP_MODO_CONFIG)) return false;
    mcp_escribir(MCP_CNF1, 0x00);
    mcp_escribir(MCP_CNF2, 0x90);
    mcp_escribir(MCP_CNF3, 0x02);
    mcp_escribir(MCP_RXB0CTRL, 0x64);
    mcp_escribir(MCP_RXB1CTRL, 0x60);
    return mcp_modo(MCP_MODO_NORMAL);
}

static bool mcp_recibir(can_frame_t *f) {
    uint8_t flags = mcp_leer(MCP_CANINTF);
    uint8_t buf, flag;
    if (flags & MCP_RX0IF)      { buf = MCP_RXB0CTRL; flag = MCP_RX0IF; }
    else if (flags & MCP_RX1IF) { buf = MCP_RXB1CTRL; flag = MCP_RX1IF; }
    else return false;

    uint8_t sidh = mcp_leer(buf + 1);
    uint8_t sidl = mcp_leer(buf + 2);
    f->dlc = mcp_leer(buf + 5) & 0x0F;
    bool valida = !(sidl & 0x08) && f->dlc <= 8;
    if (valida) {
        f->id = ((uint32_t)sidh << 3) | (sidl >> 5);
        for (uint8_t i = 0; i < f->dlc; i++) f->data[i] = mcp_leer(buf + 6 + i);
    }
    mcp_modificar(MCP_CANINTF, flag, 0);
    return valida;
}

/* ---------------- Recepcion de la posicion ---------------- */

static float pos_x, pos_y;
static int32_t angulo;
static bool hay_pose;
static uint32_t pose_ms, periodo_ms;
static uint16_t numero_pose;

static float xy_x, xy_y;
static bool xy_pendiente;
static uint32_t xy_ms;

static uint32_t ahora_ms(void) { return to_ms_since_boot(get_absolute_time()); }

static float normalizar(float a) {
    a = fmodf(a, 360.0f);
    if (a > 180.0f)  a -= 360.0f;
    if (a < -180.0f) a += 360.0f;
    return a;
}

static bool dentro_del_mapa(float x, float y) {
    float xmin = puntos[0].x, xmax = xmin, ymin = puntos[0].y, ymax = ymin;
    for (int i = 1; i < NUM_PUNTOS; i++) {
        xmin = fminf(xmin, puntos[i].x); xmax = fmaxf(xmax, puntos[i].x);
        ymin = fminf(ymin, puntos[i].y); ymax = fmaxf(ymax, puntos[i].y);
    }
    return x >= xmin - MARGEN_MAPA && x <= xmax + MARGEN_MAPA &&
           y >= ymin - MARGEN_MAPA && y <= ymax + MARGEN_MAPA;
}

static bool procesar_can(const can_frame_t *f) {
    uint32_t t = ahora_ms();
    if (f->id == CAN_POS_ID && f->dlc == 8) {
        float x, y;
        memcpy(&x, f->data, 4);
        memcpy(&y, f->data + 4, 4);
        if (!isfinite(x) || !isfinite(y) || !dentro_del_mapa(x, y)) return false;
        xy_x = x; xy_y = y; xy_ms = t; xy_pendiente = true;
    } else if (f->id == CAN_ANGLE_ID && f->dlc == 4 && xy_pendiente) {
        int32_t a;
        memcpy(&a, f->data, 4);
        xy_pendiente = false;
        if (a < -360 || a > 360 || t - xy_ms > VENTANA_DATO_MS) return false;
        if (hay_pose) periodo_ms = xy_ms - pose_ms;
        pos_x = xy_x; pos_y = xy_y;
        angulo = (int32_t)normalizar((float)a);
        pose_ms = xy_ms;
        numero_pose++;
        hay_pose = true;
        return true;
    }
    return false;
}

/* ---------------- Control del robot ---------------- */

typedef enum { ESPERANDO, ALINEANDO, AVANZANDO, FALLO, TERMINADO } Estado;
static Estado estado = ESPERANDO;
static int punto_actual = -1;
static int pasados;
static bool pausa_datos;
static float objetivo;
static float mejor_distancia;
static uint32_t inicio_tramo_ms, inicio_giro_ms, ultimo_progreso_ms;
static int32_t motor_izq, motor_der;
static const char *decision = "Esperando datos de la camara";

static struct { bool listo; uint16_t pose; uint32_t t; float ang_ant, vel; } pd;

static void reiniciar_pd(void) { memset(&pd, 0, sizeof(pd)); }

static float calcular_pd(float error, float limite) {
    if (!pd.listo) {
        pd.listo = true;
    } else if (pd.pose != numero_pose) {
        uint32_t dt_ms = pose_ms - pd.t;
        if (dt_ms < 5 || dt_ms > VENTANA_DATO_MS) {
            pd.vel = 0;
        } else {
            float dt = dt_ms / 1000.0f;
            float vel = normalizar((float)angulo - pd.ang_ant) / dt;
            pd.vel += dt / (FILTRO_D_SEG + dt) * (vel - pd.vel);
        }
    }
    pd.pose = numero_pose; pd.t = pose_ms; pd.ang_ant = (float)angulo;
    float salida = KP_ANGULO * error - KD_ANGULO * pd.vel;
    return fmaxf(-limite, fminf(limite, salida));
}

static void motores(int32_t izq, int32_t der, const char *motivo) {
    motor_izq = izq; motor_der = der; decision = motivo;
    motors_set_speeds(izq, der);
}

static void fallo(const char *motivo) {
    estado = FALLO;
    motores(0, 0, motivo);
}

static int siguiente(void) { return (punto_actual + 1) % NUM_PUNTOS; }

static float distancia_a(const Punto *p) { return hypotf(p->x - pos_x, p->y - pos_y); }

static int punto_mas_cercano(void) {
    int mejor = 0;
    for (int i = 1; i < NUM_PUNTOS; i++)
        if (distancia_a(&puntos[i]) < distancia_a(&puntos[mejor])) mejor = i;
    return mejor;
}

static float rumbo_a(const Punto *p) {
    return atan2f(p->y - pos_y, p->x - pos_x) * 180.0f / (float)M_PI;
}

static bool es_el_final(void) { return pasados == NUM_PUNTOS - 1; }

static bool llego(void) {
    const Punto *o = &puntos[punto_actual], *d = &puntos[siguiente()];
    float pasado = (pos_x - d->x) * (d->x - o->x) + (pos_y - d->y) * (d->y - o->y);
    float radio = es_el_final() ? RADIO_FINAL : RADIO_CAMBIO;
    return distancia_a(d) <= radio || pasado >= 0.0f;
}

static float velocidad_base(float distancia, float error) {
    const Punto *o = &puntos[punto_actual], *d = &puntos[siguiente()];
    bool recta = hypotf(d->x - o->x, d->y - o->y) > TRAMO_LARGO;
    return (recta && distancia > FRENAR_ANTES && fabsf(error) < 10.0f) ? VEL_RECTA : VEL_CURVA;
}

static float rumbo_en_tramo(void) {
    const Punto *o = &puntos[punto_actual], *d = &puntos[siguiente()];
    float dx = d->x - o->x, dy = d->y - o->y, largo = hypotf(dx, dy);
    if (largo < 1e-3f) return rumbo_a(d);
    float avance = ((pos_x - o->x) * dx + (pos_y - o->y) * dy) / largo + ADELANTE;
    if (avance >= largo) return rumbo_a(d);
    Punto meta = { o->x + dx * avance / largo, o->y + dy * avance / largo, 0 };
    return rumbo_a(&meta);
}

static void controlar(uint32_t t) {
    if (estado == FALLO || estado == TERMINADO) { motores(0, 0, decision); return; }
    if (!hay_pose) { motores(0, 0, "Esperando datos de la camara"); return; }

    if (t - pose_ms > VENTANA_DATO_MS) {
        if (!pausa_datos) reiniciar_pd();
        pausa_datos = true;
        motores(0, 0, "Dato lento: esperando pose nueva");
        return;
    }
    if (pausa_datos) {
        pausa_datos = false;
        inicio_tramo_ms = inicio_giro_ms = ultimo_progreso_ms = t;
    }

    if (punto_actual < 0) {
        punto_actual = punto_mas_cercano();
        inicio_tramo_ms = ultimo_progreso_ms = t;
        mejor_distancia = distancia_a(&puntos[siguiente()]);
    }

    while (llego()) {
        if (es_el_final()) {
            punto_actual = siguiente();
            estado = TERMINADO;
            motores(0, 0, "VUELTA COMPLETA: detenido en la posicion final");
            return;
        }
        punto_actual = siguiente();
        pasados++;
        inicio_tramo_ms = ultimo_progreso_ms = t;
        mejor_distancia = distancia_a(&puntos[siguiente()]);
    }
    const Punto *destino = &puntos[siguiente()];
    float distancia = distancia_a(destino);
    if (t - inicio_tramo_ms >= TRAMO_TIMEOUT_MS) { fallo("FALLO: tramo tardo demasiado"); return; }

    objetivo = rumbo_en_tramo();
    float error = normalizar(objetivo - (float)angulo);

    if (fabsf(error) > GIRO_EN_SITIO) {
        if (estado != ALINEANDO) { estado = ALINEANDO; inicio_giro_ms = t; reiniciar_pd(); }
        if (t - inicio_giro_ms >= GIRO_TIMEOUT_MS) { fallo("FALLO no gira: motores o SENTIDO_ANGULO"); return; }
        int mando = (int)fmaxf(VEL_GIRO_MIN, fminf(VEL_GIRO_MAX, KP_ANGULO * fabsf(error)));
        mando *= (error > 0 ? 1 : -1) * SENTIDO_ANGULO;
        motores(-mando, mando, mando > 0 ? "Girar en su lugar: izquierda" : "Girar en su lugar: derecha");
        return;
    }
    if (estado != AVANZANDO) {
        estado = AVANZANDO;
        reiniciar_pd();
        ultimo_progreso_ms = t;
        mejor_distancia = distancia;
    }

    if (distancia < mejor_distancia - 0.01f) {
        mejor_distancia = distancia;
        ultimo_progreso_ms = t;
    }
    if (t - ultimo_progreso_ms >= SIN_PROGRESO_MS) { fallo("FALLO: no se acerca al destino"); return; }

    float base = velocidad_base(distancia, error);
    float corr = calcular_pd(error, CORRECCION_MAX) * SENTIDO_ANGULO;
    motores((int32_t)(base - corr), (int32_t)(base + corr),
            fabsf(error) > 10.0f ? "Curva: avanzar girando" : "Avanzar recto");
}

/* ---------------- Monitor serial ---------------- */

static const char *const NOMBRE_ESTADO[] = { "ESPERANDO", "ALINEANDO", "AVANZANDO", "FALLO", "TERMINADO" };

static void reportar(uint32_t t) {
    static uint32_t ultimo;
    static int est_ant = -1, punto_ant = -2;
    static bool pausa_ant;
    bool cambio = est_ant != (int)estado || punto_ant != punto_actual || pausa_ant != pausa_datos;
    if (!cambio && t - ultimo < REPORTE_MS) return;
    ultimo = t; est_ant = estado; punto_ant = punto_actual; pausa_ant = pausa_datos;

    int dest = punto_actual < 0 ? -1 : siguiente();
    char txt[256];
    snprintf(txt, sizeof(txt),
        "%s W%d->W%d %s|xy=%.2f,%.2f a=%ld o=%.0f e=%.0f d=%.2f m=%ld/%ld edad=%lu per=%lu\n",
        NOMBRE_ESTADO[estado], punto_actual + 1, dest + 1, decision, pos_x, pos_y,
        (long)angulo, objetivo, normalizar(objetivo - (float)angulo),
        dest < 0 ? 0.0f : distancia_a(&puntos[dest]),
        (long)motor_izq, (long)motor_der,
        (unsigned long)(hay_pose ? t - pose_ms : 0), (unsigned long)periodo_ms);
    stdio_put_string(txt, (int)strlen(txt), false, false);
}

/* ---------------- Main ---------------- */

int main(void) {
    motors_init();
    motors_set_speeds(0, 0);
    stdio_init_all();
    if (!mcp_iniciar()) fallo("FALLO: no se pudo configurar el modulo CAN");

    uint32_t ultimo_control = 0;
    while (true) {
        bool nueva = false;
        can_frame_t rx;
        for (int i = 0; i < 4; i++) {
            if (!mcp_recibir(&rx)) break;
            if (procesar_can(&rx)) nueva = true;
        }
        uint32_t t = ahora_ms();
        if (nueva || t - ultimo_control >= CONTROL_MS) {
            controlar(t);
            ultimo_control = t;
        }
        reportar(t);
        sleep_ms(1);
    }
}